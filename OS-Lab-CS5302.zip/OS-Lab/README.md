# CS5302 – Operating Systems Lab
Chennai Institute of Technology | Dept. of CSE | June–October 2026

All experiments from the lab manual, organized by exercise number.
Each folder has the C program and/or shell script equivalent.

## Contents
| Ex No | Title | Folder |
|---|---|---|
| 1 | Installation of Windows OS | 01-windows-os-installation |
| 2 | UNIX Commands & Shell Programming | 02-unix-shell-programs |
| 3 | System Calls: fork, exit, getpid, wait, close | 03-system-calls |
| 4 | CPU Scheduling Algorithms (FCFS, SJF, Priority, RR) | 04-cpu-scheduling |
| 5 | Inter Process Communication (Pipe) | 05-ipc-pipe |
| 6 | Semaphore Implementation | 06-semaphore |
| 7 | Banker's Algorithm | 07-bankers-algorithm |
| 8 | Deadlock Detection Algorithm | 08-deadlock-detection |
| 9 | Threading (Pthreads) | 09-threading |
| 10 | Paging Technique | 10-paging |
| 11 | Memory Allocation (First/Best/Worst Fit) | 11-memory-allocation |
| 12 | Page Replacement (FIFO, LRU, Optimal) | 12-page-replacement |
| 13 | File Organization Techniques | 13-file-organization |
| 14 | File Allocation Strategies | 14-file-allocation |
| 15 | Disk Scheduling (FCFS, SSTF, SCAN, C-SCAN) | 15-disk-scheduling |

## Content Beyond Syllabus
| Title | Folder |
|---|---|
| Virtual Machine Performance Analyzer | extra-01-vm-performance-analyzer |
| CPU Scheduling Simulator | extra-02-cpu-scheduling-simulator |
| Memory Management Visualizer | extra-03-memory-management-visualizer |
| Disk Scheduling Simulator | extra-04-disk-scheduling-simulator |

## Compiling & running C programs
```bash
gcc program.c -o program
./program
```
For threading programs, link pthread:
```bash
gcc thread.c -o thread -pthread
```

## Running shell scripts
```bash
chmod +x script.sh
./script.sh
```
