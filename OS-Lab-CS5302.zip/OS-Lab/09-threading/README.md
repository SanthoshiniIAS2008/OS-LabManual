Compile with: gcc thread.c -o thread -pthread
Run with: ./thread
